import ServerConfig from './server_config';

let config = new ServerConfig();
config.load();

export default config;
