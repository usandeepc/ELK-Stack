# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/) and this project adheres to 
[Semantic Versioning](http://semver.org/).

## 2.0.1

### Fixed

- Fix issue where unarchive was looking for archive on local machine

## 2.0.0

### Added

- Support for textfile metrics

### Changed

- Updated the naming standard of all variables

## 1.0.0
### Added

- Everything. This is the initial release.
